package com.art.art

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
